package com.tonushree.jewellers;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.*;
import android.text.InputType;
import java.util.Locale;

public class MainActivity extends Activity {

    private final int BG = Color.rgb(7, 7, 7);
    private final int CARD = Color.rgb(20, 20, 20);
    private final int CARD2 = Color.rgb(28, 28, 28);
    private final int GOLD = Color.rgb(212, 175, 55);
    private final int GOLD2 = Color.rgb(184, 138, 42);
    private final int TEXT = Color.rgb(248, 245, 236);
    private final int MUTED = Color.rgb(185, 181, 170);

    EditText price, bhori, ana, roti, point, customBad;
    Spinner karat;
    TextView resultAmount, resultDetails, customLabel;

    final String[] ks = {
            "২২K — প্রতি ভরিতে ১.৫ আনা বাদ",
            "২১K — প্রতি ভরিতে ২ আনা বাদ",
            "২০K — প্রতি ভরিতে ৪ আনা বাদ",
            "১৮K — প্রতি ভরিতে ৬ আনা বাদ",
            "Custom — নিজের মতো বাদ"
    };

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        Window w = getWindow();
        w.setStatusBarColor(BG);
        w.setNavigationBarColor(BG);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(30));
        scroll.addView(root);

        // Brand header
        LinearLayout brandCard = card(22, GOLD, 1);
        brandCard.setGravity(Gravity.CENTER_HORIZONTAL);
        brandCard.setPadding(dp(16), dp(18), dp(16), dp(18));

        ImageView logo = new ImageView(this);
        logo.setImageResource(com.tonushree.jewellers.R.drawable.tonushree_logo_header);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        LinearLayout.LayoutParams lpLogo = new LinearLayout.LayoutParams(dp(240), dp(105));
        lpLogo.gravity = Gravity.CENTER_HORIZONTAL;
        brandCard.addView(logo, lpLogo);

        TextView title = txt("তনুশ্রী জুয়েলার্স", 27, GOLD, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(5), 0, 0);
        brandCard.addView(title, full());

        TextView sub = txt("পুরাতন স্বর্ণ হিসাব", 18, TEXT, Typeface.NORMAL);
        sub.setGravity(Gravity.CENTER);
        brandCard.addView(sub, full());

        TextView small = txt("বিশুদ্ধ হিসাব • সহজ ব্যবহার • প্রিমিয়াম ইন্টারফেস", 12, MUTED, Typeface.NORMAL);
        small.setGravity(Gravity.CENTER);
        small.setPadding(0, dp(5), 0, 0);
        brandCard.addView(small, full());

        root.addView(brandCard, withBottom(16));

        // Price & karat card
        LinearLayout infoCard = card(18, Color.rgb(56,48,25), 1);
        infoCard.setPadding(dp(16), dp(15), dp(16), dp(16));
        infoCard.addView(sectionTitle("স্বর্ণের তথ্য"));

        infoCard.addView(label("প্রতি ভরি বর্তমান মূল্য (৳)"));
        price = input("যেমন: 200000");
        infoCard.addView(price, withBottom(12));

        infoCard.addView(label("ক্যারেট / খাত নির্বাচন"));
        karat = new Spinner(this);
        ArrayAdapter<String> ad = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, ks) {
            @Override
            public View getView(int position, View convertView, android.view.ViewGroup parent) {
                TextView v = (TextView) super.getView(position, convertView, parent);
                v.setTextColor(TEXT);
                v.setTextSize(16);
                v.setPadding(dp(12), dp(12), dp(12), dp(12));
                return v;
            }
            @Override
            public View getDropDownView(int position, View convertView, android.view.ViewGroup parent) {
                TextView v = (TextView) super.getDropDownView(position, convertView, parent);
                v.setTextColor(Color.BLACK);
                v.setTextSize(16);
                v.setPadding(dp(12), dp(14), dp(12), dp(14));
                return v;
            }
        };
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        karat.setAdapter(ad);
        karat.setBackground(round(CARD2, GOLD2, 1, 12));
        infoCard.addView(karat, withBottom(10));

        customLabel = label("Custom বাদ — প্রতি ভরিতে কত আনা?");
        customBad = input("যেমন: 1.75");
        customLabel.setVisibility(View.GONE);
        customBad.setVisibility(View.GONE);
        infoCard.addView(customLabel);
        infoCard.addView(customBad, withBottom(0));

        karat.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                boolean show = pos == 4;
                customLabel.setVisibility(show ? View.VISIBLE : View.GONE);
                customBad.setVisibility(show ? View.VISIBLE : View.GONE);
            }
            public void onNothingSelected(AdapterView<?> p) {}
        });

        root.addView(infoCard, withBottom(16));

        // Weight card
        LinearLayout weightCard = card(18, Color.rgb(56,48,25), 1);
        weightCard.setPadding(dp(16), dp(15), dp(16), dp(16));
        weightCard.addView(sectionTitle("ওজন লিখুন"));

        TextView helper = txt("ভরি, আনা, রতি ও পয়েন্ট—যেটুকু আছে সেটুকুই লিখুন।", 12, MUTED, Typeface.NORMAL);
        helper.setPadding(0, 0, 0, dp(10));
        weightCard.addView(helper);

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        bhori = input("ভরি");
        ana = input("আনা");
        row1.addView(bhori, halfRight(7));
        row1.addView(ana, halfLeft(7));
        weightCard.addView(row1, withBottom(10));

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        roti = input("রতি");
        point = input("পয়েন্ট");
        row2.addView(roti, halfRight(7));
        row2.addView(point, halfLeft(7));
        weightCard.addView(row2);

        root.addView(weightCard, withBottom(16));

        Button btn = new Button(this);
        btn.setText("হিসাব করুন");
        btn.setTextSize(18);
        btn.setTextColor(Color.rgb(15, 13, 8));
        btn.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        btn.setAllCaps(false);
        btn.setBackground(round(GOLD, GOLD, 0, 16));
        btn.setPadding(dp(12), dp(14), dp(12), dp(14));
        root.addView(btn, withBottom(16));

        // Result card
        LinearLayout resultCard = card(20, GOLD, 2);
        resultCard.setPadding(dp(18), dp(18), dp(18), dp(18));

        TextView rTitle = txt("প্রাপ্য মূল্য", 14, MUTED, Typeface.BOLD);
        rTitle.setGravity(Gravity.CENTER);
        resultCard.addView(rTitle, full());

        resultAmount = txt("৳0.00", 31, GOLD, Typeface.BOLD);
        resultAmount.setGravity(Gravity.CENTER);
        resultAmount.setPadding(0, dp(5), 0, dp(10));
        resultCard.addView(resultAmount, full());

        View line = new View(this);
        line.setBackgroundColor(Color.rgb(68, 61, 40));
        resultCard.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));

        resultDetails = txt("হিসাব করতে উপরের তথ্য পূরণ করুন।", 15, TEXT, Typeface.NORMAL);
        resultDetails.setPadding(0, dp(13), 0, 0);
        resultDetails.setLineSpacing(0, 1.25f);
        resultCard.addView(resultDetails, full());

        root.addView(resultCard);

        TextView footer = txt("Tonushree Jewellers • Old Gold Calculator", 11, Color.rgb(120,115,105), Typeface.NORMAL);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(18), 0, 0);
        root.addView(footer, full());

        btn.setOnClickListener(v -> calc());
        setContentView(scroll);
    }

    private TextView sectionTitle(String s) {
        TextView t = txt(s, 18, GOLD, Typeface.BOLD);
        t.setPadding(0, 0, 0, dp(12));
        return t;
    }

    private TextView label(String s) {
        TextView t = txt(s, 13, MUTED, Typeface.BOLD);
        t.setPadding(0, dp(3), 0, dp(5));
        return t;
    }

    private EditText input(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(Color.rgb(125, 122, 115));
        e.setTextColor(TEXT);
        e.setTextSize(17);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setPadding(dp(13), dp(11), dp(13), dp(11));
        e.setBackground(round(CARD2, GOLD2, 1, 12));
        return e;
    }

    private TextView txt(String s, float size, int color, int style) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setTypeface(Typeface.create("sans", style));
        return t;
    }

    private LinearLayout card(int radius, int stroke, int width) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackground(round(CARD, stroke, width, radius));
        return l;
    }

    private GradientDrawable round(int fill, int stroke, int width, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radius));
        if (width > 0) g.setStroke(dp(width), stroke);
        return g;
    }

    private LinearLayout.LayoutParams full() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    private LinearLayout.LayoutParams withBottom(int bottomDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 0, 0, dp(bottomDp));
        return p;
    }

    private LinearLayout.LayoutParams halfRight(int gap) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1f);
        p.setMargins(0, 0, dp(gap), 0);
        return p;
    }

    private LinearLayout.LayoutParams halfLeft(int gap) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1f);
        p.setMargins(dp(gap), 0, 0, 0);
        return p;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private double d(EditText e) {
        try {
            String s = e.getText().toString().trim();
            if (s.isEmpty()) return 0;
            return Double.parseDouble(s);
        } catch (Exception x) {
            return 0;
        }
    }

    private void calc() {
        double p = d(price);
        double b = d(bhori);
        double a = d(ana);
        double r = d(roti);
        double pt = d(point);

        // ১ ভরি = ১৬ আনা, ১ আনা = ৬ রতি, ১ রতি = ১০ পয়েন্ট
        double totalPoints = b * 16 * 6 * 10 + a * 6 * 10 + r * 10 + pt;
        double grossAna = totalPoints / 60.0;

        if (p <= 0) {
            toast("প্রতি ভরি মূল্য লিখুন");
            return;
        }
        if (grossAna <= 0) {
            toast("স্বর্ণের ওজন লিখুন");
            return;
        }

        int pos = karat.getSelectedItemPosition();
        double badPerBhori = 1.5;
        if (pos == 1) badPerBhori = 2.0;
        else if (pos == 2) badPerBhori = 4.0;
        else if (pos == 3) badPerBhori = 6.0;
        else if (pos == 4) {
            String s = customBad.getText().toString().trim();
            if (s.isEmpty()) {
                toast("Custom বাদ কত আনা তা লিখুন");
                return;
            }
            badPerBhori = d(customBad);
            if (badPerBhori < 0 || badPerBhori > 16) {
                toast("Custom বাদ ০ থেকে ১৬ আনার মধ্যে দিন");
                return;
            }
        }

        showResult(p, grossAna, badPerBhori);
    }

    private void showResult(double p, double grossAna, double badPerBhori) {
        // বাদ প্রতি ভরির অনুপাতে প্রয়োগ করা হয়।
        double deductedAna = grossAna * (badPerBhori / 16.0);
        double netAna = Math.max(0, grossAna - deductedAna);
        double value = p * (netAna / 16.0);

        resultAmount.setText(String.format(Locale.US, "৳%,.2f", value));
        resultDetails.setText(String.format(
                Locale.US,
                "মূল ওজন          : %.3f আনা\n" +
                "খাত/বাদ          : প্রতি ভরিতে %.3f আনা\n" +
                "মোট বাদ          : %.3f আনা\n" +
                "বাদ দেওয়ার পর : %.3f আনা",
                grossAna, badPerBhori, deductedAna, netAna
        ));
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
